
if ( GetLocale() == "itIT" ) then
XPERL_MSG_PREFIX	= "|c00C05050X-Perl|r "

XPERL_TOOLTIP_ASSISTING	= "Giocatori che ti assistono:"
XPERL_TOOLTIP_HEALERS	= "Curatori che ti bersagliano:"
XPERL_TOOLTIP_ALLONME	= "Chi ti bersaglia:"
XPERL_TOOLTIP_ENEMYONME	= "Nemici che ti bersagliano:"
XPERL_TOOLTIP_HELP	= "Fai click per aprire la vista in tempo reale"
XPERL_TOOLTIP_PET	= "Pet di %s"

XPERL_LOC_DEAD		= "Morto"

XPERL_BUTTON_TOGGLE_LABELS	= "Abilita scritte bersagli"
XPERL_BUTTON_TOGGLE_MTTARGETS	= "Abilita la visualizzazione dei bersagli dei bersagli dei tank"
XPERL_BUTTON_TOGGLE_SHOWMT	= "Abilita la visualizzazione del Guardiano PrincipaleToggle showing of the Main Tank"
XPERL_BUTTON_HELPER_PIN		= "Blocca Finestra"

XPERL_XS_TARGET			= "Bersaglio di %s"
XPERL_NO_TARGET			= "Nessun Bersaglio"

XPERL_TITLE_MT_LONG		= "Bersagli Guardiani Principali"
XPERL_TITLE_MT_SHORT		= "GP"
XPERL_TITLE_WARRIOR_LONG	= "Bersagli Guerrieri"
XPERL_TITLE_WARRIOR_SHORT	= "Guardiani"

XPERL_HELPER_NEEDPROMOTE	= "Devi essere promosso per impostare l'assist principale"
XPERL_HELPER_MASET		= "Assist Principale impostato a %s"
XPERL_HELPER_MACLEAR		= "Assist Principale |c00FF0000eliminato!"
XPERL_HELPER_MAREMOVED		= "L'assist principale %s non è stato trovato nella lista dei guardiani - rimosso!"
XPERL_HELPER_MAREMOTESET	= "%s ha assegnato l'Assist Principale a %s"

XPERL_HELPER_FINDFOUND		= "Trovato un bersaglio adatto con FIND. ('|c00007F00/xp find|r' per eliminare)."
XPERL_HELPER_FINDCLEARED	= "FIND |c00FF0000eliminato!|r"
XPERL_HELPER_FINDSET		= "FIND impostato a %s. ('|c00007F00/xp find|r' per eliminare)."

XPERL_AGGRO_PLAYER		= "- MINACCIA -"
XPERL_AGGRO_PET			= "- FAMIGLIO MINACCIA -"
XPERL_AGGRO_DRAGTIP		= "Muovi la posizione dell'allerta della minaccia"

XPERL_LOC_DEAD = "Mort"
end
